<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
        

}

