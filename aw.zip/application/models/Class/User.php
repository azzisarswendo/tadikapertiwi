<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of User
 *
 * @author azzis
 */
Class Application_Model_Class_User {
    //put your code here
    public function fotoProfil($w, $h, $s){
        if($w < $h){
            //$h1 = eval($h + ) / 2;
            //$w1 = eval($w + $s) / 2 ;
        }
    }
}
