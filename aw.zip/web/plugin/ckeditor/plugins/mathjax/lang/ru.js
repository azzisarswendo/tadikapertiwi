/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'ru', {
	title: 'Математика в TeX-системе',
	button: 'Математика',
	dialogInput: 'Введите здесь TeX',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX документация',
	loading: 'загрузка...',
	pathName: 'мат.'
} );
